#pragma once

namespace sorting{
    void preencherVetor(int*, int, int, int, int);
    void mergeSort(int[], int, int);
    void mergeSortInPlace(int[], int, int);
    void quickSort(int, int);
    void selectionSort(int*, int);
    void insertionSort(int*, int);
    void quickSort(int*, int);
}